package com.example.GetRide;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GetRideApplication {

	public static void main(String[] args) {
		SpringApplication.run(GetRideApplication.class, args);
	}

}
